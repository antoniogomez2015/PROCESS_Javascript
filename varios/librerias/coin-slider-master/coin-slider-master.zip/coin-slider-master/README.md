Coin Slider
===========
jQuery Image Slider with Unique Transitions Effects

This is Coin Slider development repository. 

For more information and download of stable version visit: 

http://workshop.rs/projects/coin-slider/