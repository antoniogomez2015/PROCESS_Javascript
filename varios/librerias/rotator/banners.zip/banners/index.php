<!doctype html>
<html lang="es">
<head>
	<title>Banners</title>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body id="body" onload="animateRandom();">
	<a href="http://www.google.com" target="_blank"><div id="image1" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image2" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image3" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image4" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image5" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image6" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image7" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image8" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image9" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image10" class="contadorClicks"></div></a>
	<a href="http://www.google.com" target="_blank"><div id="image10" class="contadorClicks"></div></a>

</body>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/contador.js" type="text/javascript"></script>
</html>